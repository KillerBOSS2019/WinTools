from email.mime import image
import mss
import mss.tools

from PIL import Image

with mss.mss() as sct:
    # The monitor or screen part to capture
    monitor = sct.monitors[1]  # or a region

    # Grab the data
    sct_img = sct.grab(monitor)

    # Generate the PNG
    png = mss.tools.to_png(sct_img.rgb, sct_img.size)
    img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")
    print(img)
    #print(png)
    
    
import base64
import pyperclip3
from PIL import Image
import io
def getFrame_base64():
    # Get frame (only rgb - smaller size)
    frame_rgb     = mss.mss().grab(mss.mss().monitors[2]).rgb # #type: bytes, len: 1280*720*3 (w, h, r, g, b)

    # Convert it from bytes to resize
    frame_image   = Image.frombytes("RGB", (1920, 1080), frame_rgb, "raw", "RGB") 
    
    #### RESIZING THE IMAGE
    size = 512, 512
    frame_image.thumbnail(size, Image.LANCZOS)

    
    ### TEMP SAVING IMAGE TO BUFFER THEN TO BASE 64
    buffer = io.BytesIO()
    frame_image.save(buffer, format='PNG')
    frame_image.save("thumb_testimage.png", format='PNG')

    b64_str = base64.standard_b64encode(buffer.getvalue())
    
    
    frame_image.close()


    pyperclip3.copy(b64_str)
    return b64_str
    

print(getFrame_base64())


